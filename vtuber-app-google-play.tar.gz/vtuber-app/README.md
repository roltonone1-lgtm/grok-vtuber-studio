# Grok VTuber Studio

Android-приложение для Google Play.  
Аватары, трекинг лица (риг), смена причёсок, изменение голоса и тембра.

## Что внутри
- Трекинг лица через MediaPipe (landmarks = риг)
- Смена аватаров / причёсок
- Голос (pitch + тембр) через микрофон
- Готово под Capacitor → можно собрать APK/AAB для Google Play

## Как собрать APK для Google Play

### Вариант 1 — онлайн (без своего ПК)
1. Загрузи папку `vtuber-app` на GitHub.
2. Используй сервисы вроде:
   - [Capacitor Cloud Build](https://ionic.io) (есть бесплатный тариф)
   - Или онлайн Android-сборщики (Appetize, BrowserStack и т.п.)
3. Или попроси кого-то с Android Studio собрать.

### Вариант 2 — локально (когда появится ПК)
```bash
cd vtuber-app
npm install
npx cap add android
npx cap sync
npx cap open android
```
В Android Studio: Build → Generate Signed Bundle / APK.

## Структура
```
vtuber-app/
├── www/                  ← само приложение
│   ├── index.html
│   ├── manifest.json
│   └── avatars/
├── capacitor.config.json
└── package.json
```

## Что нужно для публикации в Google Play
1. Аккаунт разработчика Google Play ($25 разово)
2. Подписанный AAB (Android App Bundle)
3. Иконки 512×512 и скриншоты
4. Политика конфиденциальности (камера + микрофон)
5. Описание и категория (развлечения / социальные)

Приложение запрашивает:
- Камеру (для трекинга лица)
- Микрофон (для изменения голоса)

Готово к дальнейшей доработке (добавление VRM-моделей, лучшего voice changer, виртуальной камеры и т.д.).
